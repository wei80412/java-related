package com.ctbc.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "PCMS_FLOW_MAIN")
public class PcmsFlowMainVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SEQ", nullable = false)
	private Long seq;

	@Column(name = "DEP_ID", length = 4, nullable = false)
	private String depId;

	@Column(name = "ROC_DATE", length = 7, nullable = false)
	private String rocDate;

	@Column(name = "BUSSINESS_ID", length = 3, nullable = false)
	private String businessId;

	@Column(name = "BUSSINESS_SEQ", nullable = false)
	private Integer bussinessSeq;

	@Column(name = "CUSTOMER_ID", length = 11, nullable = true)
	private String customerId;

	@Column(name = "CUSTOMER_NAME", length = 100, nullable = true)
	private String customerName;

	@Column(name = "CUSTOMER_ACCOUNT", length = 16, nullable = true)
	private String customerAccount;

	@Column(name = "REQUEST_TELLER", length = 10, nullable = false)
	private String requestTeller;

	@Column(name = "FLOW_BRANCH", nullable = true)
	private Integer flowBranch;

	@Column(name = "STATUS", length = 1, nullable = false)
	private String status;

	@Column(name = "SLA_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date slaDate;

	@Column(name = "REJECT_FILL_STATUS", length = 1, nullable = true)
	private String rejectFillStatus;

	@Column(name = "ESB_ID", length = 50, nullable = true)
	private String esbId;

	@Version
	@Column(name = "VERSION", nullable = false)
	protected Long version;

	@Column(name = "CREATOR", length = 10, nullable = false)
	protected String creator;

	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_AT", nullable = false)
	protected Date created_at;

	@Column(name = "MODIFIER", length = 10, nullable = false)
	protected String modifier;

	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFIED_AT", nullable = false)
	protected Date modified_at;

	public Long getSeq() {
		return seq;
	}

	public void setSeq(Long seq) {
		this.seq = seq;
	}

	public String getDepId() {
		return depId;
	}

	public void setDepId(String depId) {
		this.depId = depId;
	}

	public String getRocDate() {
		return rocDate;
	}

	public void setRocDate(String rocDate) {
		this.rocDate = rocDate;
	}

	public String getBusinessId() {
		return businessId;
	}

	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}

	public Integer getBussinessSeq() {
		return bussinessSeq;
	}

	public void setBussinessSeq(Integer bussinessSeq) {
		this.bussinessSeq = bussinessSeq;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAccount() {
		return customerAccount;
	}

	public void setCustomerAccount(String customerAccount) {
		this.customerAccount = customerAccount;
	}

	public String getRequestTeller() {
		return requestTeller;
	}

	public void setRequestTeller(String requestTeller) {
		this.requestTeller = requestTeller;
	}

	public Integer getFlowBranch() {
		return flowBranch;
	}

	public void setFlowBranch(Integer flowBranch) {
		this.flowBranch = flowBranch;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getSlaDate() {
		return slaDate;
	}

	public void setSlaDate(Date slaDate) {
		this.slaDate = slaDate;
	}

	public String getRejectFillStatus() {
		return rejectFillStatus;
	}

	public void setRejectFillStatus(String rejectFillStatus) {
		this.rejectFillStatus = rejectFillStatus;
	}

	public String getEsbId() {
		return esbId;
	}

	public void setEsbId(String esbId) {
		this.esbId = esbId;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getCreated_at() {
		return created_at;
	}

	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public Date getModified_at() {
		return modified_at;
	}

	public void setModified_at(Date modified_at) {
		this.modified_at = modified_at;
	}

	@Override
	public String toString() {
		return "PcmsFlowMainVO [seq=" + seq + ", depId=" + depId + ", rocDate=" + rocDate + ", businessId=" + businessId
				+ ", bussinessSeq=" + bussinessSeq + ", customerId=" + customerId + ", customerName=" + customerName
				+ ", customerAccount=" + customerAccount + ", requestTeller=" + requestTeller + ", flowBranch="
				+ flowBranch + ", status=" + status + ", slaDate=" + slaDate + ", rejectFillStatus=" + rejectFillStatus
				+ ", esbId=" + esbId + ", version=" + version + ", creator=" + creator + ", created_at=" + created_at
				+ ", modifier=" + modifier + ", modified_at=" + modified_at + "]";
	}

}
