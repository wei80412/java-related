package com.ctbc.service;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ctbc.model.PcmsFlowMainVO;

@Repository
public class CommonFlowDao {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Transactional
	public List<PcmsFlowMainVO> getAllFlowMain() {
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query = session.createSQLQuery("select top 10 * from pcms_flow_main order by seq desc").addEntity(PcmsFlowMainVO.class);
		List<PcmsFlowMainVO> resultList = query.list();
		return resultList;
	}

}
