package com.ctbc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctbc.model.PcmsFlowMainVO;

@Service
public class CommonFlowService {

	@Autowired
	private CommonFlowDao commonFlowDao;

	public List<PcmsFlowMainVO> getAllFlowMain() {
		return commonFlowDao.getAllFlowMain();
	}

}
