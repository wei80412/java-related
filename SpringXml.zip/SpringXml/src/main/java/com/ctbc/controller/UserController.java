package com.ctbc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ctbc.model.UserVO;

@Controller
@RequestMapping("/user")
public class UserController {

	@RequestMapping(value = "register", method = RequestMethod.GET)
	public String showRegistrationForm() {
		return "registerForm";
	}

	@RequestMapping(value = "register", method = RequestMethod.POST)
	public String processRegistration(UserVO userVO) {
		System.out.println(userVO.toString());
		return "redirect:/spring/user/selectPage/" + userVO.getUserName();
	}

	@RequestMapping(value = "/selectPage/{userName}", method = RequestMethod.GET)
	public String toSelectPage(@PathVariable String userName) {
		System.out.println("to select page");
		return "selectPage";
	}
}
