package com.ctbc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ctbc.model.PcmsFlowMainVO;
import com.ctbc.service.CommonFlowService;

@Controller
@RequestMapping("/testSpringMVC")
public class FlowController {
	
	public FlowController() {
		System.out.println("FlowController");
	}
	
	@Autowired
	private CommonFlowService commonFlowService;

	@RequestMapping(value = "/getAllFlowMainModel", method = RequestMethod.GET)
	public String getAllFlowMain(Model model) {
		System.out.println(" 呼叫 SpringMVC Controller : getAllFlowMain(Model model) ");
		List<PcmsFlowMainVO> flowMainList = commonFlowService.getAllFlowMain();
		model.addAttribute(flowMainList);
		model.addAttribute("modelFlowMainList"/* 前端EL取資料的name */, flowMainList); //大致上與request.setAttribute() 相似
//		int i = 1/0;
		return "result";// 視圖解析器 viewResolver 會在此字串補 【前綴 & 後綴】 → "/WEB-INF/" + "hello" + ".jsp" 進而找到對應的視圖
	}
	
	@RequestMapping(value = "/getAllFlowMainRequest", method = RequestMethod.GET)
	public String getAllFlowMain(HttpServletRequest request) {
		System.out.println(" 呼叫 SpringMVC Controller : getAllFlowMain(HttpServletRequest request) ");
		List<PcmsFlowMainVO> flowMainList = commonFlowService.getAllFlowMain();
		request.setAttribute("flowMainList", flowMainList);
		return "result";// 視圖解析器 viewResolver 會在此字串補 【前綴 & 後綴】 → "/WEB-INF/" + "hello" + ".jsp" 進而找到對應的視圖
	}

}
