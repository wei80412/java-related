package com.ctbc.aspect;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class FlowAspect {
	
	public FlowAspect() {
		System.out.println("========= FlowAspect ==========");
	}

	// 1. return type => **
	// 2. package name => com.ctbc.controller
	// 3. class name => FlowController
	// 4. function name => **
	// 5. parameters => ..
	@Pointcut("execution(** com.ctbc.controller.FlowController.**(..))")
	private void pointCut() {
	}
	
	@Before(value="pointCut()")
	public void beforeGetAll() {
		System.out.println("Before Get All");
	}
	
	@AfterReturning(value="pointCut()")
	public void afterReturningGetAll() {
		System.out.println("After Returning Get All");
	}
	
	@AfterThrowing(value="pointCut()")
	public void afterGetAll() {
		System.out.println("After Throwing Get All");
	}
}
